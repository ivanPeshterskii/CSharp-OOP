﻿using System.Diagnostics.Metrics;

namespace ShoppingSpree.Models
{
	public class StartUp
	{
		public static void Main(string[] args)
		{
			try
			{
				var peopleInput = Console.ReadLine().Split(';', StringSplitOptions.RemoveEmptyEntries);
				var people = new List<Person>();
				foreach (var personData in peopleInput)
				{
					var parts = personData.Split('=');
					string name = parts[0];
					int money = int.Parse(parts[1]);
					people.Add(new Person(name, money));
				}

				var productInput = Console.ReadLine().Split(';', StringSplitOptions.RemoveEmptyEntries);
				var products = new List<Product>();
				foreach (var productData in productInput)
				{
					var parts = productData.Split('=');
					string name = parts[0];
					int money = int.Parse(parts[1]);
					products.Add(new Product(name, money));
				}

                string command;
                while ((command = Console.ReadLine()) != "END")
                {
                    var parts = command.Split(' ', StringSplitOptions.RemoveEmptyEntries);
                    string personName = parts[0];
                    string productName = parts[1];

                    var person = people.FirstOrDefault(p => p.Name == personName);
                    var product = products.FirstOrDefault(p => p.Name == productName);

                    if (person != null && product != null)
                    {
                        person.BuyProduct(product);
                    }

                    foreach (var person1 in people)
                    {
                        string productsBought = person1.Bag.Count > 0
                            ? string.Join(", ", person1.Bag.Select(p => p.Name))
                            : "Nothing bought";

                        Console.WriteLine($"{person1.Name} - {productsBought}");
                    }
                }
            }
			catch (ArgumentException ex)
			{
				Console.WriteLine(ex.Message);
			}
		}
	}
}